Measure Bootstrap Theme

Credits:

- Lato Google webfont http://www.google.com/webfonts/specimen/Lato
- Icons by Brankic1979 http://www.brankic1979.com/icons/
- Sample blog image bought from http://es.123rf.com/photo_8349325_encantado-paisaje-de-nepal.html - electronic license
- Carousel iPhone image from http://www.pixeden.com/psd-mock-up-templates/3d-view-iphone-5-psd-vector-mockup
- Social icons from http://medialoot.com/item/round-social-media-icons/